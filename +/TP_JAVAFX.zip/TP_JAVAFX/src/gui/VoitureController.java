package gui;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import metier.ConnexionDB;
import metier.Voiture;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class VoitureController implements Initializable{
    @FXML
    private TextField fieldMat;
    @FXML
    private TextField fieldNom;
    @FXML
    private TextField fieldPrix;
    @FXML
    private ListView listeView;
   @FXML
   private Button buttonAdd;
    private Connection connx;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        try {
            connx= ConnexionDB.getConnection();
            Statement stm=connx.createStatement();
            ResultSet rs=stm.executeQuery("select * from voitures");
            while (rs.next()){
                listeView.getItems().add(new Voiture(rs.getString("matricule"),rs.getString("nom")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public  void ajouterVoiture(){
        try {
            Statement stm=connx.createStatement();
            String mat=fieldMat.getText();
            String nom=fieldNom.getText();
            float prix=Float.parseFloat(fieldPrix.getText());
            stm.executeUpdate("insert into voitures vGBalues(null,'"+mat+"','"+nom+"',"+prix+")");
            listeView.getItems().add(new Voiture(mat,nom));

        }catch(Exception e){
         e.printStackTrace();
        }



    }
    public void supprimerVoiture(){
        int indice=listeView.getSelectionModel().getSelectedIndex();
        if(indice>=0) {
            listeView.getItems().remove(indice);
        }else{
            Alert alert=new Alert(Alert.AlertType.WARNING);
            alert.setContentText("Veuillez sélectionner un élément ");
            alert.show();
        }
    }

    public TextField getFieldPrix() {
        return fieldPrix;
    }

    public void setFieldPrix(TextField fieldPrix) {
        this.fieldPrix = fieldPrix;
    }

    public TextField getFieldMat() {
        return fieldMat;
    }

    public void setFieldMat(TextField fieldMat) {
        this.fieldMat = fieldMat;
    }

    public void setFieldNom(TextField fieldNom) {
        this.fieldNom = fieldNom;
    }

    public TextField getFieldNom() {
        return fieldNom;
    }

    public ListView getListeView() {
        return listeView;
    }

    public void setListeView(ListView listeView) {
        this.listeView = listeView;
    }
}
