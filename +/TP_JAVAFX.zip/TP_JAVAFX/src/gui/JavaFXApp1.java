package gui;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class JavaFXApp1 extends Application {
    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) throws Exception {
        BorderPane root=new BorderPane();
        Label labelNom=new Label("Nom :");
        TextField fieldNom=new TextField();
        Button buttonAdd=new Button("Ajouter");
        Button buttonDel=new Button("Supprimer");
        HBox hBox=new HBox();
        hBox.setPadding(new Insets(15));
        hBox.setSpacing(5);
        hBox.getChildren().addAll(labelNom,fieldNom,buttonAdd,buttonDel);
        root.setTop(hBox);
        ListView<String> listView=new ListView<>();
        listView.getItems().addAll("BMX","MERCEDEZ","FIAT");
        root.setCenter(listView);
       buttonAdd.setOnAction(new EventHandler<ActionEvent>() {
           @Override
           public void handle(ActionEvent event) {
              String nom=fieldNom.getText();
               listView.getItems().add(nom);
           }
       });
      buttonDel.setOnAction(new EventHandler<ActionEvent>() {
          @Override
          public void handle(ActionEvent event) {
              //récupérer l'indice de l'élément sélectionné
           int indice=listView.getSelectionModel().getSelectedIndex();
          if(indice>=0) {
              listView.getItems().remove(indice);
          }else{
              Alert alert=new Alert(Alert.AlertType.WARNING);
              alert.setContentText("Veuillez sélectionner un élément ");
              alert.show();
          }
          }
      });
        Scene scene=new Scene(root,500,400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
