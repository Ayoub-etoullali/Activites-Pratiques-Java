package gui;

import java.sql.*;

public class ApplicationDB {
    public static void main(String[] args) {
        try {
            //charger le pilote jdbc
            Class.forName("com.mysql.jdbc.Driver");
            //créer la connexion avec la base de données
            Connection connx= DriverManager.getConnection("jdbc:mysql://localhost:3306/db_magasin","root","");
           //créer un objet Statement
            Statement stm=connx.createStatement();
            //exécuter une requête d'insertion
            /*stm.executeUpdate("insert into voitures(matricule,nom,prix)" +
                                    "values('108OKH','DACUIA',150000)");*/
            //exécuter une requête de suppression
            /*stm.executeUpdate("delete from voitures where id=1");*/
            //exécuter une requête de modification
            //stm.executeUpdate("update voitures set nom='MERCEDES',prix=400000 where id=2");
            //exécuter une requête de selection
            ResultSet rs=stm.executeQuery("select * from voitures");
            /*while(rs.next()){
                System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+
                                 rs.getString(3)+"\t"+rs.getFloat(4));

            }*/
           /* while(rs.next()){
                System.out.println(rs.getInt("id")+"\t"+rs.getString("matricule")+"\t"+
                        rs.getString("nom")+"\t"+rs.getFloat("prix"));

            }*/
           ResultSetMetaData rsm= rs.getMetaData();
           while(rs.next()){
               for(int i=1;i<= rsm.getColumnCount();i++){
                   System.out.print(rs.getString(rsm.getColumnName(i))+"\t");
               }
               System.out.println();
           }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
