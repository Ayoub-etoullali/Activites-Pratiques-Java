import java.io.File;
import java.io.IOException;

public class Application1 {
    public static void main(String[] args) {
      try{
          File file=new File("C:/xampp");
          String contenu[]=file.list();
          for(int i=0;i<contenu.length;i++){
              File file1=new File(contenu[i]);
              if(file1.isDirectory()){
                  System.out.println("Rep :"+contenu[i]);
              }else{
                  System.out.println("File :"+contenu[i]);
              }
          }
          File file2=new File("file1.txt");
          if(file2.exists()){
              System.out.println("Le fichier existe");
          }else{
              System.out.println("Le fihcier n'estiste pas");
              file2.createNewFile();
          }
      }catch (IOException e){
          System.out.println(e.getMessage());
      }

    }
}
