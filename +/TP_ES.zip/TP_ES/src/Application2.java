import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Application2 {
    public static void main(String[] args) {
        try{
            File f1=new File("file1.txt");
            FileReader fr=new FileReader(f1);
            File f2=new File("file2.txt");
            FileWriter fw=new FileWriter(f2);

            int c;
            while ((c=fr.read())!=-1){
                fw.write(c);
            }
            fr.close();
            fw.close();
        }catch (IOException e){
            e.printStackTrace();
        }

    }
}
