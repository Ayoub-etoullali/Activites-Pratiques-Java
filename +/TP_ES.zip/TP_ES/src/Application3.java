import java.io.*;

public class Application3 {
    public static void main(String[] args) {
        try{
            File f1=new File("enset1.jpg");
            FileInputStream fis=new FileInputStream(f1);
            File f2=new File("enset2.jpg");
            FileOutputStream fos=new FileOutputStream(f2);

            int c;
            while ((c=fis.read())!=-1){
                fos.write(c);
            }
            fis.close();
            fos.close();
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}
