import metier.Etudiant;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Application5 {
    public static void main(String[] args) {
        try {
            Etudiant e1 = new Etudiant("nom1", "prenom1", 17.5f);
            Etudiant e2 = new Etudiant("nom2", "prenom2", 14);
            Etudiant e3 = new Etudiant("nom3", "prenom3", 10.5f);
            File f1 = new File("etudiants.bat");
            FileOutputStream fos = new FileOutputStream(f1);
            ObjectOutputStream oos=new ObjectOutputStream(fos);
            oos.writeObject(e1);
            oos.writeObject(e2);
            oos.writeObject(e3);
            oos.close();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
