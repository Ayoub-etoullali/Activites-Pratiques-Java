import metier.Etudiant;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class Application6 {
    public static void main(String[] args) {
        try {
            File f1=new File("etudiants.bat");
            FileInputStream fis=new FileInputStream(f1);
            ObjectInputStream ois=new ObjectInputStream(fis);
            Etudiant e1=(Etudiant) ois.readObject();
            Etudiant e2=(Etudiant) ois.readObject();
            Etudiant e3=(Etudiant) ois.readObject();
            System.out.println(e1.getNom()+" : "+e1.getNote());
            System.out.println(e2.getNom()+" : "+e2.getNote());
            System.out.println(e3.getNom()+" : "+e3.getNote());
            ois.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
