public class Triplet<T,T1> extends Paire<T>{
     private T1 c;
     public Triplet(){

     }

    public Triplet(T a, T b, T1 c) {
        super(a, b);
        this.c = c;
    }

    public T1 getC() {
        return c;
    }

    public void setC(T1 c) {
        this.c = c;
    }
}
