public class Manager extends Employe{
    private String specialite;

    public Manager() {
    }

    public Manager(String nom, String prenom, float salaire, String specialite) {
        super(nom, prenom, salaire);
        this.specialite = specialite;
    }

    public String getSpecialite() {
        return specialite;
    }

    public void setSpecialite(String specialite) {
        this.specialite = specialite;
    }
}
