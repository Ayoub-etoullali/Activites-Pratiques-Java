public interface MonInterface <T>{
     void afficher(T a);
}
