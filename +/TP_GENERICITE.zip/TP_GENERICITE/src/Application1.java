import java.util.ArrayList;
import java.util.List;

public class Application1 {
    public static void main(String[] args) {

        //version avec un seul type générique
        Paire<String> p1=new Paire<String>("str1","str2");
        System.out.println(p1.getA());
        System.out.println(p1.getB());
        Employe e1=new Employe("nom1","prenom1",14000);
        Employe e2=new Employe("nom2","prenom2",24000);
        Paire<Employe> p2=new Paire<>(e1,e2);
        System.out.println(p2.getA().getNom());
        System.out.println(p2.getB().getNom());
        Paire<Integer> p3=new Paire<>(4,6);
        System.out.println(p3.getA());
        System.out.println(p3.getB());

       /*
        version avec deux types génériques
        Employe e1=new Employe("nom1","prenom1",14000);
        Paire<String,Employe> p1=new Paire<>("str1",e1);
        System.out.println(p1.getA());
        System.out.println(p1.getB().getNom());*/
    }
}
