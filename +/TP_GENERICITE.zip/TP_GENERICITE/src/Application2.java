public class Application2 {
    public static void main(String[] args) {
      Triplet<String,Integer> p1=new Triplet<>("str1","str2",5);
        System.out.println(p1.getA());
        System.out.println(p1.getB());
        System.out.println(p1.getC());
        TripletNonGenerique p2=new TripletNonGenerique("str1","str2",9.5);
        System.out.println(p2.getA());
        System.out.println(p2.getC());
    }
}
