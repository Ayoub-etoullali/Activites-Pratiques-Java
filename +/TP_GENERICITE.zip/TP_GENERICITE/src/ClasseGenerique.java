import java.io.Serializable;

public class ClasseGenerique <T extends Employe&Serializable&Cloneable> {
    private  T a;

    public ClasseGenerique(T a) {
        this.a = a;
    }

    public T getA() {
        return a;
    }

    public void setA(T a) {
        this.a = a;
    }
}
