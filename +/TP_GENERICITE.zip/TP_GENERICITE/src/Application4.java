public class Application4 {
    public static void main(String[] args) {
        Operation op=new Operation();
        System.out.println(op.comparer(6,6));
        System.out.println(op.comparer("str1","str2"));

    }
}
