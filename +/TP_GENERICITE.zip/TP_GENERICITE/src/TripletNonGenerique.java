public class TripletNonGenerique extends Paire<String>{
    private Double c;

    public TripletNonGenerique() {
    }

    public TripletNonGenerique(String a, String b, Double c) {
        super(a, b);
        this.c = c;
    }

    public Double getC() {
        return c;
    }

    public void setC(Double c) {
        this.c = c;
    }
}
