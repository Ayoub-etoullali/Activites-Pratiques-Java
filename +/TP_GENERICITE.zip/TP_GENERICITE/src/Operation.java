public class Operation{
    public <T> boolean comparer(T a,T b){
        return a.equals(b);
    }
}
