import java.util.ArrayList;
import java.util.List;

public class Application3 {
    public static void main(String[] args) {
        ClasseGenerique<Employe> c1=new ClasseGenerique(new Employe("nom1","prenom1",14000));
        ClasseGenerique<Employe> c2=new ClasseGenerique(new Employe("nom2","prenom2",14000));
        ClasseGenerique<Manager> c3=new ClasseGenerique(new Manager("nom3","prenom3",14000,"s1"));
        List<ClasseGenerique<? extends Employe>> list=new ArrayList<>();
        list.add(c1);
        list.add(c2);
        list.add(c3);
        for (ClasseGenerique<? extends Employe> e:list) {
            if(e.getA() instanceof Manager)
               System.out.println(((Manager) e.getA()).getSpecialite());
            else
                System.out.println(e.getA().getNom());
        }
    }
}
