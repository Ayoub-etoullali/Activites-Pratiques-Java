public class MonInterfaceImpl implements MonInterface<Employe>{

    @Override
    public void afficher(Employe a) {
        System.out.println(a.getNom()+" "+a.getPrenom());
    }
}
