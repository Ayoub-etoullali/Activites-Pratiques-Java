package metier;

public class Voiture {
    private String matricule;
    private String marque;

    public Voiture(String matricule,String marque) {
        this.marque = marque;
        this.matricule=matricule;
    }

    public String getMarque() {
        return marque;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }

    @Override
    public String toString() {
        return "Marque: " + marque+" Matricule: "+matricule;
    }
}
