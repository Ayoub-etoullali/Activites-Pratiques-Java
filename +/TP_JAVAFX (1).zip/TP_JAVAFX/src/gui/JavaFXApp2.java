package gui;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import metier.Voiture;

public class JavaFXApp2 extends Application {
    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) throws Exception {
        BorderPane root=new BorderPane();
        Label labelMatr=new Label("Matricule :");
        Label labelMarque=new Label("Marque :");
        TextField fieldMat=new TextField();
        TextField fieldMarque=new TextField();
        Button buttonAdd=new Button("Ajouter");
        Button buttonDel=new Button("Supprimer");
        HBox hBox=new HBox();
        hBox.setPadding(new Insets(15));
        hBox.setSpacing(5);
        hBox.getChildren().addAll(labelMatr,fieldMat,labelMarque,fieldMarque,buttonAdd,buttonDel);
        root.setTop(hBox);
        ObservableList<Voiture> voitures= FXCollections.observableArrayList();
        ListView<Voiture> listView=new ListView<>(voitures);
        voitures.addAll(new Voiture("BMX","1324HG"),new Voiture("MERCEDEZ","8U75V"),new Voiture("FIAT","76YHF"));
        root.setCenter(listView);
       buttonAdd.setOnAction(new EventHandler<ActionEvent>() {
           @Override
           public void handle(ActionEvent event) {
              String mat=fieldMat.getText();
              String marque=fieldMat.getText();
               voitures.add(new Voiture(mat,marque));
           }
       });
      buttonDel.setOnAction(new EventHandler<ActionEvent>() {
          @Override
          public void handle(ActionEvent event) {
              //récupérer l'indice de l'élément sélectionné
           int indice=listView.getSelectionModel().getSelectedIndex();
          if(indice>=0) {
              voitures.remove(indice);
          }else{
              Alert alert=new Alert(Alert.AlertType.WARNING);
              alert.setContentText("Veuillez sélectionner un élément ");
              alert.show();
          }
          }
      });
        Scene scene=new Scene(root,500,400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
