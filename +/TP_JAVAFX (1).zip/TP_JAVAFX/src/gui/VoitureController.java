package gui;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import metier.Voiture;

public class VoitureController {
    @FXML
    private TextField fieldMat;
    @FXML
    private TextField fieldMarque;
    @FXML
    private ListView listeView;

    public  void ajouterVoiture(){
        String mat=fieldMat.getText();
        String marque=fieldMarque.getText();
        listeView.getItems().add(new Voiture(mat,marque));
    }
    public void supprimerVoiture(){
        int indice=listeView.getSelectionModel().getSelectedIndex();
        if(indice>=0) {
            listeView.getItems().remove(indice);
        }else{
            Alert alert=new Alert(Alert.AlertType.WARNING);
            alert.setContentText("Veuillez sélectionner un élément ");
            alert.show();
        }
    }

    public TextField getFieldMat() {
        return fieldMat;
    }

    public void setFieldMat(TextField fieldMat) {
        this.fieldMat = fieldMat;
    }

    public TextField getFieldMarque() {
        return fieldMarque;
    }

    public void setFieldMarque(TextField fieldMarque) {
        this.fieldMarque = fieldMarque;
    }

    public ListView getListeView() {
        return listeView;
    }

    public void setListeView(ListView listeView) {
        this.listeView = listeView;
    }
}
