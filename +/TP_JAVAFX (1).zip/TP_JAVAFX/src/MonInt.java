public interface MonInt {
    void afficher();
}
