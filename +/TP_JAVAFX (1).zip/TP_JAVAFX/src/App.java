public class App {
    public static void main(String[] args) {
        MonInt monInt=new MonInt() {
            @Override
            public void afficher() {
                System.out.println("Bonjour");
            }
        };
        monInt.afficher();
    }
}
