package presentation;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import metier.Departement;
import metier.IMetier;
import metier.MetierImpl;

import java.net.URL;
import java.util.ResourceBundle;

public class DepartementController implements Initializable {
    @FXML
    private TextField nomTextField;

    @FXML
    private TableView<Departement> deparementTableView;

    @FXML
    private TableColumn<Departement,Integer> idColumn;

    @FXML
    private TableColumn<Departement,String> nomColumn;
    @FXML
    private TextField rechercherTextField;

    ObservableList<Departement>  departements= FXCollections.observableArrayList();
    IMetier metier= new MetierImpl();
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("idDepart"));
        nomColumn.setCellValueFactory(new PropertyValueFactory<>("nom"));
        departements.addAll(metier.getAllDepartements());
        deparementTableView.setItems(departements);
        rechercherTextField.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                departements.setAll(metier.getDepartementsParMC(rechercherTextField.getText())) ;
            }
        });
    }

    public void ajouterDepartement(){
      String nom=nomTextField.getText();
      Departement d=new Departement(nom);
      metier.ajouterDepartement(d);
      departements.setAll(metier.getAllDepartements());
    }
}
