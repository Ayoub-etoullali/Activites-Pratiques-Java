package presentation;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import metier.Departement;
import metier.IMetier;
import metier.MetierImpl;
import metier.Professeur;

import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;

public class ProfesseurController implements Initializable {
    @FXML
    private TextField nomTextField;

    @FXML
    private TextField prenomTextField;

    @FXML
    private DatePicker dateRecrutementPicker;

    @FXML
    private ComboBox<Departement> departementComboBox;

    @FXML
    private TableView<Professeur> professeursTableView;

    @FXML
    private TableColumn<Professeur, Integer> idColumn;

    @FXML
    private TableColumn<Professeur, String> nomColumn;

    @FXML
    private TableColumn<Professeur, String> prenomColumn;
    @FXML
    private TableColumn<Professeur, Date> dateColumn;
    @FXML
    private  TableColumn<Professeur,Departement> departementColumn;
    IMetier metier=new MetierImpl();
    ObservableList<Professeur> professeurs= FXCollections.observableArrayList();
    @Override
    public void initialize(URL location, ResourceBundle resources) {
      idColumn.setCellValueFactory(new PropertyValueFactory<>("idProf"));
      nomColumn.setCellValueFactory(new PropertyValueFactory<>("nom"));
      prenomColumn.setCellValueFactory(new PropertyValueFactory<>("prenom"));
      dateColumn.setCellValueFactory(new PropertyValueFactory<>("dateRecrutement"));
      departementColumn.setCellValueFactory(new PropertyValueFactory<>("departement"));
      professeurs.setAll(metier.getAllProfesseurs());
      professeursTableView.setItems(professeurs);
      departementComboBox.getItems().setAll(metier.getAllDepartements());
    }

    public void ajouterProfesseur(){

        String nom=nomTextField.getText();
        String prenom=prenomTextField.getText();
        Date dateR=Date.valueOf(dateRecrutementPicker.getValue().toString());
        Departement d=departementComboBox.getSelectionModel().getSelectedItem();
        Professeur p=new Professeur(nom,prenom,dateR);
        p.setDepartement(d);
        metier.ajouterProfesseur(p);
        professeurs.setAll(metier.getAllProfesseurs());
    }
}
