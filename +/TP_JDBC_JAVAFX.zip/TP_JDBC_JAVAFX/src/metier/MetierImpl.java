package metier;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MetierImpl implements IMetier{
    private Connection connection;

    public MetierImpl() {
        connection=SingletonConnexionDB.getConnection();
    }

    @Override
    public List<Departement> getAllDepartements() {
        List<Departement> departements=new ArrayList<>();
        try {
            PreparedStatement pstm=connection.prepareStatement("select * from DEPARTEMENTS");
            pstm.executeQuery();
            ResultSet rs= pstm.getResultSet();
            while (rs.next()){
                Departement d=new Departement();
                d.setIdDepart(rs.getInt("ID_DEPART"));
                d.setNom(rs.getString("NOM"));
                departements.add(d);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return departements;
    }

    @Override
    public void ajouterDepartement(Departement d) {
        try {
            PreparedStatement pstm=connection.prepareStatement("insert into DEPARTEMENTS(NOM) values(?)");
            pstm.setString(1,d.getNom());
            pstm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Departement> getDepartementsParMC(String mc) {
        List<Departement> departements=new ArrayList<>();
        try {
            PreparedStatement pstm=connection.prepareStatement("select * from DEPARTEMENTS where NOM like ?");
            pstm.setString(1,"%"+mc+"%");
            pstm.executeQuery();
            ResultSet rs= pstm.getResultSet();
            while (rs.next()){
                Departement d=new Departement();
                d.setIdDepart(rs.getInt("ID_DEPART"));
                d.setNom(rs.getString("NOM"));
                departements.add(d);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return departements;
    }

    @Override
    public List<Professeur> getAllProfesseurs() {
        List<Professeur> professeurs=new ArrayList<>();
        try {
            PreparedStatement pstm=connection.prepareStatement("select * from PROFESSEURS");
            pstm.executeQuery();
            ResultSet rs= pstm.getResultSet();
            while (rs.next()){
                Professeur p=new Professeur();
                p.setIdProf(rs.getInt("ID_PROF"));
                p.setNom(rs.getString("NOM"));
                p.setPrenom(rs.getString("PRENOM"));
                p.setDateRecrutement(rs.getDate("DATE_RECRUTEMENT"));
                int idD= rs.getInt("ID_DEPART");
                Departement departement=getDepartementByID(idD);
                p.setDepartement(departement);
                professeurs.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return professeurs;
    }

    @Override
    public void ajouterProfesseur(Professeur p) {
        try {
            PreparedStatement pstm=connection.prepareStatement("insert into PROFESSEURS(NOM,PRENOM,DATE_RECRUTEMENT,ID_DEPART) values(?,?,?,?)");
            pstm.setString(1,p.getNom());
            pstm.setString(2,p.getPrenom());
            pstm.setDate(3,p.getDateRecrutement());
            pstm.setInt(4,p.getDepartement().getIdDepart());
            pstm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Departement getDepartementByID(int idD) {
        Departement departement=new Departement();;
        try {
            PreparedStatement pstm=connection.prepareStatement("select * from DEPARTEMENTS where ID_DEPART=?");
            pstm.setInt(1,idD);
            pstm.executeQuery();
            ResultSet rs= pstm.getResultSet();
            if (rs.next()){
                departement.setIdDepart(rs.getInt("ID_DEPART"));
                departement.setNom(rs.getString("NOM"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return departement;
    }
}
