package metier;

import java.util.List;

public interface IMetier {
    List<Departement> getAllDepartements();
    void ajouterDepartement(Departement d);
    List<Departement> getDepartementsParMC(String mc);
    List<Professeur> getAllProfesseurs();
    void ajouterProfesseur(Professeur p);
    Departement getDepartementByID(int idD);
}
