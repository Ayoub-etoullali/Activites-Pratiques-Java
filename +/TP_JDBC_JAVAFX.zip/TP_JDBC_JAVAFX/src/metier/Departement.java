package metier;


import java.io.Serializable;
//entité ou une classe persitante
public class Departement implements Serializable {
    private int idDepart;
    private String nom;

    public Departement() {
    }

    public Departement(String nom) {
        this.nom = nom;
    }

    public int getIdDepart() {
        return idDepart;
    }

    public void setIdDepart(int idDepart) {
        this.idDepart = idDepart;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    @Override
    public String toString() {
        return  nom;
    }
}
