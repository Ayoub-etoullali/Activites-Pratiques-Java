package metier;

import java.util.ArrayList;
import java.util.List;

public class Test {
    public static void main(String[] args) {
        IMetier metier=new MetierImpl();
        //Departement d1=new Departement("Mécanique");
        //metier.ajouterDepartement(d1);
        List<Departement> departements=new ArrayList<>();
        departements=metier.getAllDepartements();
        for (Departement d:departements) {
            System.out.println(d.getIdDepart()+" "+d.getNom());
        }
    }
}
