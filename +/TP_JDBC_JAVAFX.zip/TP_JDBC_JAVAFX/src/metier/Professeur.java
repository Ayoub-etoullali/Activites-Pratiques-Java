package metier;

import java.io.Serializable;
import java.sql.Date;

public class Professeur implements Serializable {
    private int idProf;
    private String nom;
    private String prenom;
    private Date dateRecrutement;
    private Departement departement;

    public Professeur() {
    }

    public Professeur(String nom, String prenom, Date dateRecrutement) {
        this.nom = nom;
        this.prenom = prenom;
        this.dateRecrutement = dateRecrutement;
    }

    public int getIdProf() {
        return idProf;
    }

    public void setIdProf(int idProf) {
        this.idProf = idProf;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public Date getDateRecrutement() {
        return dateRecrutement;
    }

    public void setDateRecrutement(Date dateRecrutement) {
        this.dateRecrutement = dateRecrutement;
    }

    public Departement getDepartement() {
        return departement;
    }

    public void setDepartement(Departement departement) {
        this.departement = departement;
    }
}
