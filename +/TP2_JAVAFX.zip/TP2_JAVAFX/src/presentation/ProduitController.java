package presentation;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import metier.IMetier;
import metier.MetierImpl;
import metier.Produit;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class ProduitController implements Initializable {
  @FXML
  private TextField fieldMc;
  @FXML
  private Button buttonRech;
  @FXML
  private TableView<Produit> tableProduits;
  @FXML
  private TableColumn<Produit,Integer> clID;
  @FXML
    private TableColumn<Produit,String> clNom;
  @FXML
  private TableColumn<Produit,Float> clPrix;
  @FXML
  private TableColumn<Produit,Integer> clQuantite;
 ObservableList<Produit> liste= FXCollections.observableArrayList();
 private IMetier metier;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        clID.setCellValueFactory(new PropertyValueFactory<>("idP"));
        clNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        clPrix.setCellValueFactory(new PropertyValueFactory<>("prix"));
        clQuantite.setCellValueFactory(new PropertyValueFactory<>("quantite"));

        metier=new MetierImpl();
        liste.addAll(metier.getAllProduits());
        tableProduits.setItems(liste);
    }

    public void Rechercher(){
       String mc=fieldMc.getText();
        List<Produit> produits=metier.getProduitsParMC(mc);
          liste.clear();
          liste.addAll(produits);
    }
}
