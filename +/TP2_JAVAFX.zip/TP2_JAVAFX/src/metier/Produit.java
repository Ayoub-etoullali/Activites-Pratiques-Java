package metier;

import java.io.Serializable;

public class Produit implements Serializable {
    private int idP;
    private String nom;
    private float prix;
    private int quantite;
    private Categorie categorie;

    public Produit() {
    }

    public Produit( String nom, float prix, int quantite,Categorie categorie) {
        this.nom = nom;
        this.prix = prix;
        this.quantite = quantite;
        this.categorie=categorie;
    }
    public Produit(int idP, String nom, float prix, int quantite,Categorie categorie) {
        this.nom = nom;
        this.prix = prix;
        this.quantite = quantite;
        this.categorie=categorie;
        this.idP=idP;
    }
    public Categorie getCategorie() {
        return categorie;
    }

    public void setCategorie(Categorie categorie) {
        this.categorie = categorie;
    }

    public int getIdP() {
        return idP;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public float getPrix() {
        return prix;
    }

    public void setPrix(float prix) {
        this.prix = prix;
    }

    public int getQuantite() {
        return quantite;
    }

    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }
}
