package metier;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class MetierImpl implements IMetier{
    @Override
    public void addCategorie(Categorie c) {
        Connection conn=SignletonConnectionDB.getConnection();
        try {
            PreparedStatement pstm=conn.prepareStatement("insert into Categorie(NOM) values (?)");
            pstm.setString(1,c.getNom());
            pstm.executeUpdate();
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    public List<Categorie> getAllCategories() {
        Connection conn=SignletonConnectionDB.getConnection();
        List<Categorie> categories=new ArrayList<>();
        try {
            PreparedStatement pstm=conn.prepareStatement("select * from Categorie");
            ResultSet rs= pstm.executeQuery();
           while (rs.next()){
                 Categorie c=new Categorie(rs.getInt("ID_CAT"),rs.getString("NOM"));
                 categories.add(c);
           }
        }catch (Exception e){
            e.printStackTrace();
        }
        return  categories;
    }

    @Override
    public List<Produit> getProduitsByCat(Categorie c) {
        Connection conn=SignletonConnectionDB.getConnection();
        List<Produit> produits=new ArrayList<>();
        try {
            PreparedStatement pstm=conn.prepareStatement("select * from PRODUIT where ID_CAT=?");
            pstm.setInt(1,c.getIdC());
            ResultSet rs= pstm.executeQuery();
            while (rs.next()){
                Produit p=new Produit(rs.getInt("ID_PROD"),rs.getString("NOM"),rs.getFloat("PRIX"), rs.getInt("QUANTITE"),c);
                produits.add(p);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return  produits;
    }

    @Override
    public void addProduit(Produit p) {
        Connection conn=SignletonConnectionDB.getConnection();
        try {
            PreparedStatement pstm=conn.prepareStatement("insert into PRODUIT(NOM,PRIX,QUANTITE,ID_CAT) " +
                    "values (?,?,?,?)");
            pstm.setString(1,p.getNom());
            pstm.setFloat(2,p.getPrix());
            pstm.setInt(3,p.getQuantite());
            pstm.setInt(4,p.getCategorie().getIdC());
            pstm.executeUpdate();
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    public List<Produit> getAllProduits() {
        Connection conn=SignletonConnectionDB.getConnection();
        List<Produit> produits=new ArrayList<>();
        try {
            PreparedStatement pstm=conn.prepareStatement("select * from PRODUIT");
            ResultSet rs= pstm.executeQuery();
            while (rs.next()){
                PreparedStatement pstm1=conn.prepareStatement("select * from CATEGORIE where ID_CAT=?");
                pstm1.setInt(1,rs.getInt("ID_CAT"));
                ResultSet rs1= pstm1.executeQuery();
                Categorie c=null;
                if(rs1.next()){
                    c=new Categorie(rs1.getInt("ID_CAT"),rs1.getString("NOM"));
                }
                Produit p=new Produit(rs.getInt("ID_PROD"),rs.getString("NOM"),rs.getFloat("PRIX"), rs.getInt("QUANTITE"),c);
                produits.add(p);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return  produits;
    }

    @Override
    public List<Produit> getProduitsParMC(String motCle) {
        Connection conn=SignletonConnectionDB.getConnection();
        List<Produit> produits=new ArrayList<>();
        try {
            PreparedStatement pstm=conn.prepareStatement("select * from PRODUIT where NOM like ?");
            pstm.setString(1,"%"+motCle+"%");
            ResultSet rs= pstm.executeQuery();
            while (rs.next()){
                PreparedStatement pstm1=conn.prepareStatement("select * from CATEGORIE where ID_CAT=?");
                pstm1.setInt(1,rs.getInt("ID_CAT"));
                ResultSet rs1= pstm1.executeQuery();
                Categorie c=null;
                if(rs1.next()){
                    c=new Categorie(rs1.getInt("ID_CAT"),rs1.getString("NOM"));
                }
                Produit p=new Produit(rs.getInt("ID_PROD"),rs.getString("NOM"),rs.getFloat("PRIX"), rs.getInt("QUANTITE"),c);
                produits.add(p);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return  produits;
    }
}
