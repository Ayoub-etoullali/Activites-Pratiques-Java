package metier;

import java.util.List;

public class Application {
    public static void main(String[] args) {
        IMetier metier=new MetierImpl();
        /*Categorie c1=new Categorie("gaming");
        Categorie c2=new Categorie("Workstation");
        metier.addCategorie(c1);
        metier.addCategorie(c2);*/
        List<Categorie> categories=metier.getAllCategories();
        for(Categorie c:categories){
            System.out.println(c.getIdC());
        }
       /* metier.addProduit(new Produit("HP",12000,3,categories.get(0)));
        metier.addProduit(new Produit("HP worksation",14000,3,categories.get(1)));
        metier.addProduit(new Produit("mac",24000,1,categories.get(0)));
         */
        List<Produit> produits=metier.getProduitsParMC("Mac");
        for (Produit p:produits){
            System.out.println(p.getNom()+" "+p.getCategorie().getNom());
        }
    }
}
