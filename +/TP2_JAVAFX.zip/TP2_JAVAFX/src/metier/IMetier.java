package metier;

import java.util.List;

public interface IMetier {
    void addCategorie(Categorie c);
    List<Categorie>  getAllCategories();
    List<Produit> getProduitsByCat(Categorie c);
    void addProduit(Produit p);
    List<Produit> getAllProduits();
    List<Produit> getProduitsParMC(String motCle);
}
