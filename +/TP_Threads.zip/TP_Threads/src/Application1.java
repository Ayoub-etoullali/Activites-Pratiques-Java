import java.io.BufferedWriter;

public class Application1 {
    public static void main(String[] args) throws InterruptedException {
         ClasseThread t1=new ClasseThread("T1");
         ClasseThread t2=new ClasseThread("T2");
         //t1.setPriority(Thread.MIN_PRIORITY);
         //t2.setPriority(Thread.MAX_PRIORITY);
        System.out.println(Thread.currentThread().getName());
         //t1.start();
         //t2.start();
    }
}
