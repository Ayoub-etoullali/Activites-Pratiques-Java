public class ClasseThread1 implements Runnable{
    private String nom;
    private int nb;

    public ClasseThread1(String nom) {
        this.nom = nom;
    }

    @Override
    public void run() {
        for(int i=0;i<10000;i++){
               synchronized (this){
                   nb++;
               }
        }
        System.out.println(nom+":"+nb);
    }
}
