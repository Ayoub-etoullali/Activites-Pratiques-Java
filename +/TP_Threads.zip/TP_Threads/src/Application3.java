import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Application3 {
    public static void main(String[] args) {
        ClasseThread t1=new ClasseThread("T1");
        ClasseThread t2=new ClasseThread("T2");
        ClasseThread t3=new ClasseThread("T3");
        ClasseThread t4=new ClasseThread("T4");
        ClasseThread t5=new ClasseThread("T5");
        ExecutorService service= Executors.newFixedThreadPool(3);
        service.execute(t1);
        service.execute(t2);
        service.execute(t3);
        service.execute(t4);
        service.execute(t5);
        service.shutdown();
    }
}
