public class ClasseThread extends Thread{
   private static int nb;

    public ClasseThread(String nom) {
        super(nom);
    }
    public synchronized static void incremeter(){
        nb++;
    }
    @Override
    public synchronized void run() {
              for(int i=0;i<10000;i++){
                  incremeter();
              }

        System.out.println(nb);
        System.out.println(Thread.currentThread().getName());
    }
}
