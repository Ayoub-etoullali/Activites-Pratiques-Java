public class Application2 {
    public static void main(String[] args) {
        ClasseThread1 t1=new ClasseThread1("T1");
        ClasseThread1 t2=new ClasseThread1("T2");

        new Thread(t1).start();
        new Thread(t1).start();
    }
}
