public interface MonInterface {
    int calcul(int a,int b);
}
